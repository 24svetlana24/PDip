﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для AddUserWindow.xaml
    /// </summary>
    public partial class AddUserWindow : Window
    {
        bd10Entities1 Database;
        public AddUserWindow()
        {
            InitializeComponent();
            Database = new bd10Entities1();
            RoleComboBox.ItemsSource = Database.Rol.ToList();
        }


        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Users user = new Users();
            user.ID = Int16.Parse(IdTextBox.Text);
            user.FIO = NameTextBox.Text;
            user.Login = LoginTextBox.Text;
            user.Rol = RoleComboBox.SelectedValue as Rol;
            user.Password = PasswordTextBox.Text;

            Database.Users.Add(user);
            Database.SaveChanges();
            (this.Owner as Window1).Loader();
        }
    }
}
