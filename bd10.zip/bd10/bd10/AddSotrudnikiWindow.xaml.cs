﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для AddSotrudnikiWindow.xaml
    /// </summary>
    public partial class AddSotrudnikiWindow : Window
    {
        bd10Entities1 Database;
        public AddSotrudnikiWindow()
        {
            InitializeComponent();
            Database = new bd10Entities1();
            id_dolComboBox.ItemsSource = Database.Dol.ToList();
            id_genderComboBox.ItemsSource = Database.Gender.ToList();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Sotrudniki user = new Sotrudniki();
            user.id = Int16.Parse(IdTextBox.Text);
            user.surname = surnameTextBox.Text;
            user.name = nameTextBox.Text;
            user.middle_name = middle_nameTextBox.Text;
            user.Dol = id_dolComboBox.SelectedValue as Dol;
            user.date = dateDataPicker.SelectedDate;
            user.number = numberTextBox.Text;
            user.Gender = id_genderComboBox.SelectedValue as Gender;

            Database.Sotrudniki.Add(user);
            Database.SaveChanges();
            (this.Owner as SotrudnikiWindow).Loader();
        }
    }
}
